This is the code repository for the MFE Toolbox, a set of MATLAB routines 
primarily for modeling financial time series, although many of the 
functions are useful in other econometric problems, such as modeling 
macroeconomic time series data or applications to cross-sectional data.
